angular.module('meanSongs').controller('LoginController',LoginController);
angular.module('meanSongs').controller('LoginValidator',LoginValidator);

function LoginValidator($http,$scope,$routeParams,){

var password=$routeParams.pass;
var email = $routeParams.id;
firebase.auth().signInWithEmailAndPassword(email, password).catch(function(error) {
  // Handle Errors here.
  var errorCode = error.code;
  var errorMessage = error.message;
  // ...
});	
	
}


function LoginController($http,$scope){

	
}