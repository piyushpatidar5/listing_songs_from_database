angular.module('meanSongs').controller('SongsController',SongsController);
angular.module('meanSongs').controller('SignupController',SignupController);

angular.module('meanSongs').controller('LoginAuthenticationController',LoginAuthenticationController);


function SongsController($http,$scope,$routeParams){
var vm=this;

	vm.title = 'Collection of Songs from my Database';	
	
	$http.get('/api/songs').then(function(response){
		console.log(response.data);
		vm.songs = response.data;
    	
});
}


function LoginAuthenticationController($http,$scope,$routeParams){

var password=$routeParams.pass;
var email = $routeParams.id;
 var vm =this;

firebase.auth().signInWithEmailAndPassword(email, password)
     .then(function(firebaseUser) {
     
	vm.title = 'Collection of Songs from my Database';	
	
	$http.get('/api/songs').then(function(response){
		console.log(response.data);
		vm.songs = response.data;
	});
   })
  .catch(function(error) {
      alert("Login Failed");
	  window.location = "http://localhost:8800/#!/Login";
  });
    
  	
	
}


function SignupController($http,$scope,$routeParams){

var password=$routeParams.pass;
var email = $routeParams.id;
 var vm =this;

  
  
 firebase.auth().createUserWithEmailAndPassword(email, password).then(function(firebaseUser) {
     
	 alert("SignUp Successfull");
	  window.location = "http://localhost:8800/#!/Login";
 })
  .catch(function(error) {
      alert("Signup Failed");
	  window.location = "http://localhost:8800/#!/Login";
  });
    
 }


