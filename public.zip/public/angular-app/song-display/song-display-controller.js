angular.module('meanSongs').controller('SongDisplayController',SongDisplayController);
function SongDisplayController($http,$routeParams){
	var vm =this;
	var id = $routeParams.id;
	
	console.log(id);
	
	$http.get('/api/songs/'+id).then(function(response){
		console.log(response.data);
		vm.song = response.data;
	});
	
}


