var app=angular.module('meanSongs',['ngRoute']);

app.config(function($routeProvider){
	//console.log("called");
	$routeProvider
	.when('/songs/:id',{
		templateUrl : 'angular-app/song-display/song-display.html',
		controller : SongDisplayController,
		controllerAs : 'vm'
	})
	.when('/',{
		templateUrl : 'angular-app/song-list/songs-list.html',
		controller : SongsController,
		controllerAs : 'vm'
	});	
	
});