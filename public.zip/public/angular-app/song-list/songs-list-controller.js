angular.module('meanSongs').controller('SongsController',SongsController);
function SongsController($http){
	
	//console.log("calling from List");
	
	var vm =this;
	vm.title = 'MEAN Songs app';	
	
	$http.get('/api/songs').then(function(response){
		console.log(response.data);
		vm.songs = response.data;
	});
	
}


